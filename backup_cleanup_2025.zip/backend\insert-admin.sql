INSERT OR REPLACE INTO usuarios (email, hash_pass, rol, activo, creado_en)
VALUES ('admin@test.edu', '$2b$10$Tknum/R/r28KAoYOutUy1uaNDzwA1F0ZKmfuaDrgObQ8Jnkxx/Hay', 'admin', 1, datetime('now'));
